# Truck Center 2 Irmãos — Site

Site institucional responsivo para oficina de mecânica a diesel.

## Antes de publicar
1. O WhatsApp já está configurado: (19) 99644-7325.
2. O endereço já está configurado: Tv. Antartica, 156.
3. O horário já está configurado: 08:00 às 18:00.
4. Para adicionar fotos reais, substitua o bloco visual da seção "Sobre" ou adicione uma galeria.

## Publicação gratuita
Você pode publicar estes arquivos gratuitamente no GitHub Pages ou Netlify.
