// ATENÇÃO: substitua o número abaixo pelo WhatsApp real da oficina.
// Formato: 5511999999999 (55 + DDD + número, sem espaços ou símbolos).
const WHATSAPP = "5519996447325";

document.getElementById("year").textContent = new Date().getFullYear();

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuToggle.addEventListener("click", () => nav.classList.toggle("open"));

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});

document.getElementById("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const nome = document.getElementById("nome").value.trim();
  const telefone = document.getElementById("telefone").value.trim();
  const mensagem = document.getElementById("mensagem").value.trim();

  const texto = `Olá, Truck Center 2 Irmãos!%0A%0A` +
    `Meu nome é ${encodeURIComponent(nome)}.%0A` +
    `Telefone: ${encodeURIComponent(telefone)}.%0A%0A` +
    `${encodeURIComponent(mensagem)}`;

  window.open(`https://wa.me/${WHATSAPP}?text=${texto}`, "_blank");
});
